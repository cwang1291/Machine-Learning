Do not change the directory structure of the archive when submitting. Do not change the name of any of the existing files and folders. Simply copy over the existing files, create a TAR archive (with the identical directory structure as the template archive). A common mistake is to create a ZIP archive instead of a TAR archive.

Submit the TAR archive in Autolab.

Failing to do so may result in your submission being empty to the graders.

